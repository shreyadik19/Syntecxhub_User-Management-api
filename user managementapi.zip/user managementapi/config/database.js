// config/database.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
require('dotenv').config();

const dbPath = process.env.DATABASE_PATH || './database.db';
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('❌ Database connection error:', err.message);
    } else {
        console.log('✅ Connected to SQLite database');
    }
});

// Create sample data
db.serialize(() => {
    // Create table
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            age INTEGER NOT NULL,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Add sample data
    db.get(`SELECT COUNT(*) as count FROM users`, (err, row) => {
        if (!err && row.count === 0) {
            const sampleUsers = [
                ['John Doe', 'john@example.com', 25, 'active'],
                ['Jane Smith', 'jane@example.com', 30, 'active'],
                ['Bob Wilson', 'bob@example.com', 35, 'inactive']
            ];
            
            const stmt = db.prepare(`INSERT INTO users (name, email, age, status) VALUES (?, ?, ?, ?)`);
            sampleUsers.forEach(user => stmt.run(user));
            stmt.finalize();
            
            console.log('✅ Sample users added to database');
        }
    });
});

module.exports = db;